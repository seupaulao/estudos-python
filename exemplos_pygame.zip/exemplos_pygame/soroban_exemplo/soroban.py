import os, sys, pygame
from pygame.locals import *

WINSIZE = [640,220]
WINCENTER = [320, 240]

if not pygame.font: print 'Warning, fonts disabled'
if not pygame.mixer: print 'Warning, sound disabled'

#funcao para carregar uma  imagem
def load_image(name, colorkey=None):
    fullname = os.path.join('data', name)
    try:
        image = pygame.image.load(fullname)
    except pygame.error, message:
        print 'Cannot load image:', fullname
        raise SystemExit, message
    image = image.convert()
    if colorkey is not None:
        if colorkey is -1:
            colorkey = image.get_at((0,0))
        image.set_colorkey(colorkey, RLEACCEL)
    return image, image.get_rect()


 
             
class Rato(pygame.sprite.Sprite):
      def __init__(self):
          pygame.sprite.Sprite.__init__(self)
          self.image, self.rect = load_image('rato.bmp',-1)
          self.clicado = 0
      
      def update(self):
          pos = pygame.mouse.get_pos()
          self.rect.midtop = pos

      def clica(self, alvo):
          if not self.clicado:    
             self.clicado = 1
             colide = self.rect.inflate(-5, -5)
             return colide.colliderect(alvo.rect)
      
      def naoclica(self):
          self.clicado = 0      

class Pedra(pygame.sprite.Sprite):
      def __init__(self, pos=600, alt=20, valor=0):
          pygame.sprite.Sprite.__init__(self)
          self.image, self.rect = load_image('desligado.bmp',-1)
          self.pos = pos
          self.rect.center = (self.pos,alt)
          self.status = 0
          self.altura = alt
          self.valor = valor
      
      def getValor(self):
          return self.valor 

      def getStatus(self):
          return self.status
 
      def update(self):
          if self.status==0:
             self.image, self.rect = load_image('desligado.bmp',-1)
             self.rect.center = (self.pos,self.altura)
          else:
             self.image, self.rect = load_image('ligado.bmp',-1)
             self.rect.center = (self.pos,self.altura)
 
      def mudaStatus(self):
          if self.status == 0:
             self.status = 1
          else:
             self.status = 0
  

class Numero(pygame.sprite.Sprite):
      def __init__(self, posx, posy, num_inicial = 0):
          pygame.sprite.Sprite.__init__(self)
          self.image, self.rect = load_image(str(num_inicial) + '.bmp',-1)
          self.posx = posx
          self.posy = posy
          self.rect.center = (posx,posy)
          self.numero = num_inicial
 
      def update(self):
          self.image, self.rect = load_image(str(self.numero) + '.bmp',-1)
          self.rect.center = (self.posx,self.posy)

      def setNumero(self, num):
          self.numero = num
           


class Barra:
      def __init__(self, posx, posy, incy=30):
          self.barra_im = pygame.sprite.RenderClear()
          self.barra_im.add(Pedra(posx,posy,           5))       
          self.barra_im.add(Pedra(posx,posy + incy,    1))       
          self.barra_im.add(Pedra(posx,posy + incy * 2,1))       
          self.barra_im.add(Pedra(posx,posy + incy * 3,1))       
          self.barra_im.add(Pedra(posx,posy + incy * 4,1))
          self.barra = [0,0,0,0,0]
          self.numero = Numero(posx, posy + incy * 5,0)
          self.numero_im = pygame.sprite.RenderClear(self.numero)

      def valorBarra(self):
          valor_barra = 0
          if self.barra[0] == 1: valor_barra += self.barra_im.sprites()[0].getValor()
          if self.barra[1] == 1: valor_barra += self.barra_im.sprites()[1].getValor()
          if self.barra[2] == 1: valor_barra += self.barra_im.sprites()[2].getValor()
          if self.barra[3] == 1: valor_barra += self.barra_im.sprites()[3].getValor()
          if self.barra[4] == 1: valor_barra += self.barra_im.sprites()[4].getValor()
          return valor_barra

      def printBarra(self):
          x = self.valorBarra()
          self.numero.setNumero(x)
          self.numero_im.update()

      def update(self, pedra):
          for i in range(len(self.barra_im.sprites())):
                if pedra == self.barra_im.sprites()[i]:
                   break
          pedra.mudaStatus()
          self.barra[i] = pedra.getStatus()
 
      def zeraBarra(self):
          for i in range(len(self.barra_im.sprites())):
              self.barra_im.sprites[i].status = 0
              self.barra[i] = 0 

class Abaco:
      def __init__(self,posx=600,posy=20,dist_barra=30,incy=30,num_barras=1):
          self.barras = []
          for i in range(num_barras):
              self.barras.append(Barra(posx - dist_barra * i, posy, incy))
              

 

def main():
    pygame.init()
    
    tela = pygame.display.set_mode(WINSIZE)
    pygame.display.set_caption('Teste de Soroban')
    pygame.mouse.set_visible(0)
    
    background_image, background_rect = load_image('fundo.bmp')    
    tela.blit(background_image,(0,0))

    #mbarra = Barra(600,20)
    #mbarra1 = Barra(570,20)
    #mbarra2 = Barra(540,20)
    #mbarra3 = Barra(510,20)
    #mbarra4 = Barra(480,20)
    abaco = Abaco(600,20,30,30,15)

    rato = Rato()
    rato_im = pygame.sprite.RenderClear(rato)

    while 1:
         pygame.time.delay(10)
       
         for event in pygame.event.get():
             if event.type in (QUIT, KEYDOWN):
                sys.exit()
             elif event.type == MOUSEBUTTONDOWN:
                  for barra in abaco.barras:
                      p = pygame.sprite.spritecollideany(rato, barra.barra_im)
                      if p<>None:
                         barra.update(p)
                         barra.printBarra()

             elif event.type == MOUSEBUTTONUP:
                rato.naoclica()    
      
         rato_im.update()
         tela.blit(background_image, (0,0))

         for barra in abaco.barras:
             barra.barra_im.update()
             barra.barra_im.draw(tela)
             barra.numero_im.draw(tela)

         rato_im.draw(tela)

         pygame.display.flip()      



if __name__=='__main__' : main()
