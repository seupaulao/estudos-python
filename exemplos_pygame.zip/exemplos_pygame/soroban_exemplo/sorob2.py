import os, sys, pygame
from pygame.locals import *

WINSIZE = [640,220]
WINCENTER = [320, 240]

if not pygame.font: print 'Warning, fonts disabled'
if not pygame.mixer: print 'Warning, sound disabled'

#funcao para carregar uma  imagem
def load_image(name, colorkey=None):
    pasta = './data'
    fullname = os.path.join(pasta, name)
    try:
        image = pygame.image.load(fullname)
    except pygame.error, message:
        print 'Cannot load image:', fullname
        raise SystemExit, message
    image = image.convert()
    if colorkey is not None:
        if colorkey is -1:
            colorkey = image.get_at((0,0))
        image.set_colorkey(colorkey, RLEACCEL)
    return image, image.get_rect()


 
             
class Rato(pygame.sprite.Sprite):
      def __init__(self):
          pygame.sprite.Sprite.__init__(self)
          self.image, self.rect = load_image('rato.bmp',-1)
          self.clicado = 0
      
      def update(self):
          pos = pygame.mouse.get_pos()
          self.rect.midtop = pos

      def clica(self, alvo):
          if not self.clicado:    
             self.clicado = 1
             colide = self.rect.inflate(-5, -5)
             return colide.colliderect(alvo.rect)
      
      def naoclica(self):
          self.clicado = 0      

class Pedra(pygame.sprite.Sprite):
      def __init__(self, pos=600, alt=20, pos_pedra=0):
          pygame.sprite.Sprite.__init__(self)
          self.image, self.rect = load_image('desligado.bmp',-1)
          self.pos = pos
          self.rect.center = (self.pos,alt)
          self.status = 0
          self.altura = alt
          #self.valor = valor
          self.pospedra = pos_pedra
      
      def getPosicaoPedra(self):
          return self.pospedra       

      #def getValor(self):
      #    return self.valor 

      def getStatus(self):
          return self.status

      def setStatus(self, vl):
           self.status = vl
 
      def update(self):
          if self.status==0:
             self.image, self.rect = load_image('desligado.bmp',-1)
             self.rect.center = (self.pos,self.altura)
          else:
             self.image, self.rect = load_image('ligado.bmp',-1)
             self.rect.center = (self.pos,self.altura)
 
      def mudaStatus(self):
          if self.status == 0:
             self.status = 1
          else:
             self.status = 0
  

class Numero(pygame.sprite.Sprite):
      def __init__(self, posx, posy, num_inicial = 0):
          pygame.sprite.Sprite.__init__(self)
          self.image, self.rect = load_image(str(num_inicial) + '.bmp',-1)
          self.posx = posx
          self.posy = posy
          self.rect.center = (posx,posy)
          self.numero = num_inicial
 
      def update(self):
          self.image, self.rect = load_image(str(self.numero) + '.bmp',-1)
          self.rect.center = (self.posx,self.posy)

      def setNumero(self, num):
          self.numero = num
           


class Barra:
      def __init__(self, posx, posy, incy=30):
          self.barra_im = pygame.sprite.RenderPlain()
          self.barra_im.add(Pedra(posx,posy,           0))       
          self.barra_im.add(Pedra(posx,posy + incy,    1))       
          self.barra_im.add(Pedra(posx,posy + incy * 2,2))       
          self.barra_im.add(Pedra(posx,posy + incy * 3,3))       
          self.barra_im.add(Pedra(posx,posy + incy * 4,4))
          self.barra = [0,0,0,0,0]
          self.numero = Numero(posx, posy + incy * 5,0)
          self.numero_im = pygame.sprite.RenderClear(self.numero)

      def buscaIndiceSprite(self, posicao):
          if self.barra_im.sprites()[0].getPosicaoPedra()==posicao : return 0
          if self.barra_im.sprites()[1].getPosicaoPedra()==posicao : return 1
          if self.barra_im.sprites()[2].getPosicaoPedra()==posicao : return 2
          if self.barra_im.sprites()[3].getPosicaoPedra()==posicao : return 3
          if self.barra_im.sprites()[4].getPosicaoPedra()==posicao : return 4

      def valorBarra(self):
          valor_barra = 0
          if self.barra[0] == 1: valor_barra += 5
          if self.barra[1] == 1: valor_barra += 1
          if self.barra[2] == 1: valor_barra += 1
          if self.barra[3] == 1: valor_barra += 1
          if self.barra[4] == 1: valor_barra += 1
          return valor_barra

      def printBarra(self,flag=0):
          if flag==1:
             print str(self.barra)
          x = self.valorBarra()
          self.numero.setNumero(x)
          self.numero_im.update()

      def update(self, pedra):
          for i in range(len(self.barra_im.sprites())):
                if pedra == self.barra_im.sprites()[i]:
                   break
          pedra.mudaStatus()
          ppedra = pedra.getPosicaoPedra()
          self.barra[ppedra] = pedra.getStatus()
          if self.barra[ppedra] == 1:
             if (ppedra==4) and (self.barra[ppedra-1]==0):
                self.barra[3]=1
                self.barra_im.sprites()[self.buscaIndiceSprite(3)].setStatus(1)
                self.barra[2]=1
                self.barra_im.sprites()[self.buscaIndiceSprite(2)].setStatus(1)
                self.barra[1]=1
                self.barra_im.sprites()[self.buscaIndiceSprite(1)].setStatus(1)
             elif (ppedra==3) and (self.barra[ppedra-1]==0):
                self.barra[2]=1
                self.barra_im.sprites()[self.buscaIndiceSprite(2)].setStatus(1)
                self.barra[1]=1
                self.barra_im.sprites()[self.buscaIndiceSprite(1)].setStatus(1)
             elif (ppedra==2) and (self.barra[ppedra-1]==0):
                self.barra[1]=1
                self.barra_im.sprites()[self.buscaIndiceSprite(1)].setStatus(1)
          else:
             if (ppedra==1) and (self.barra[ppedra+1]==1):
                self.barra[2]=0
                self.barra_im.sprites()[self.buscaIndiceSprite(2)].setStatus(0)
                self.barra[3]=0
                self.barra_im.sprites()[self.buscaIndiceSprite(3)].setStatus(0)
                self.barra[4]=0
                self.barra_im.sprites()[self.buscaIndiceSprite(4)].setStatus(0)
             elif (ppedra==2) and (self.barra[ppedra+1]==1):
                self.barra[3]=0
                self.barra_im.sprites()[self.buscaIndiceSprite(3)].setStatus(0)
                self.barra[4]=0
                self.barra_im.sprites()[self.buscaIndiceSprite(4)].setStatus(0)
             elif (ppedra==3) and (self.barra[ppedra+1]==1):
                self.barra[4]=0
                self.barra_im.sprites()[self.buscaIndiceSprite(4)].setStatus(0)

 
      def zeraBarra(self):
          for i in range(len(self.barra_im.sprites())):
              self.barra_im.sprites[i].status = 0
              self.barra[i] = 0 

class Abaco:
      def __init__(self,posx=600,posy=20,dist_barra=30,incy=30,num_barras=1):
          self.barras = []
          for i in range(num_barras):
              self.barras.append(Barra(posx - dist_barra * i, posy, incy))
              

 

def main():
    pygame.init()
    
    tela = pygame.display.set_mode(WINSIZE)
    pygame.display.set_caption('Teste de Soroban')
    pygame.mouse.set_visible(0)
    
    background_image, background_rect = load_image('fundo.bmp')    
    tela.blit(background_image,(0,0))

    mbarra1 = Barra(620,20)
    mbarra2 = Barra(580,20)
    mbarra3 = Barra(540,20)
    mbarra4 = Barra(500,20)
    mbarra5 = Barra(460,20)
    mbarra6 = Barra(420,20)
    mbarra7 = Barra(380,20)
    mbarra8 = Barra(340,20)
    mbarra9 = Barra(300,20)
    mbarra10 = Barra(260,20)
    mbarra11 = Barra(220,20)
    mbarra12 = Barra(180,20)
    mbarra13 = Barra(140,20)
    mbarra14 = Barra(100,20)
    mbarra15 = Barra(60,20)
    #abaco = Abaco(600,20,30,30,15)

    rato = Rato()
    rato_im = pygame.sprite.RenderClear(rato)

    while 1:
         pygame.time.delay(30)
       
         for event in pygame.event.get():
             if event.type in (QUIT, KEYDOWN):
                sys.exit()
             elif event.type == MOUSEBUTTONDOWN:
                  #for barra in abaco.barras:
                      p = pygame.sprite.spritecollideany(rato, mbarra1.barra_im)
                      if p<>None:
                         mbarra1.update(p)
                         mbarra1.printBarra()
                      p = pygame.sprite.spritecollideany(rato, mbarra2.barra_im)
                      if p<>None:
                         mbarra2.update(p)
                         mbarra2.printBarra()
                      p = pygame.sprite.spritecollideany(rato, mbarra3.barra_im)
                      if p<>None:
                         mbarra3.update(p)
                         mbarra3.printBarra()
                      p = pygame.sprite.spritecollideany(rato, mbarra4.barra_im)
                      if p<>None:
                         mbarra4.update(p)
                         mbarra4.printBarra()
                      p = pygame.sprite.spritecollideany(rato, mbarra5.barra_im)
                      if p<>None:
                         mbarra5.update(p)
                         mbarra5.printBarra()
                      p = pygame.sprite.spritecollideany(rato, mbarra6.barra_im)
                      if p<>None:
                         mbarra6.update(p)
                         mbarra6.printBarra()
                      p = pygame.sprite.spritecollideany(rato, mbarra7.barra_im)
                      if p<>None:
                         mbarra7.update(p)
                         mbarra7.printBarra()
                      p = pygame.sprite.spritecollideany(rato, mbarra8.barra_im)
                      if p<>None:
                         mbarra8.update(p)
                         mbarra8.printBarra()
                      p = pygame.sprite.spritecollideany(rato, mbarra9.barra_im)
                      if p<>None:
                         mbarra9.update(p)
                         mbarra9.printBarra()
                      p = pygame.sprite.spritecollideany(rato, mbarra10.barra_im)
                      if p<>None:
                         mbarra10.update(p)
                         mbarra10.printBarra()
                      p = pygame.sprite.spritecollideany(rato, mbarra11.barra_im)
                      if p<>None:
                         mbarra11.update(p)
                         mbarra11.printBarra()
                      p = pygame.sprite.spritecollideany(rato, mbarra12.barra_im)
                      if p<>None:
                         mbarra12.update(p)
                         mbarra12.printBarra()
                      p = pygame.sprite.spritecollideany(rato, mbarra13.barra_im)
                      if p<>None:
                         mbarra13.update(p)
                         mbarra13.printBarra()
                      p = pygame.sprite.spritecollideany(rato, mbarra14.barra_im)
                      if p<>None:
                         mbarra14.update(p)
                         mbarra14.printBarra()
                      p = pygame.sprite.spritecollideany(rato, mbarra15.barra_im)
                      if p<>None:
                         mbarra15.update(p)
                         mbarra15.printBarra()

             elif event.type == MOUSEBUTTONUP:
                rato.naoclica()    
      
         rato_im.update()
         tela.blit(background_image, (0,0))

         mbarra1.barra_im.update()
         mbarra2.barra_im.update()
         mbarra3.barra_im.update()
         mbarra4.barra_im.update()
         mbarra5.barra_im.update()
         mbarra6.barra_im.update()
         mbarra7.barra_im.update()
         mbarra8.barra_im.update()
         mbarra9.barra_im.update()
         mbarra10.barra_im.update()
         mbarra11.barra_im.update()
         mbarra12.barra_im.update()
         mbarra13.barra_im.update()
         mbarra14.barra_im.update()
         mbarra15.barra_im.update()

         mbarra1.barra_im.draw(tela)
         mbarra2.barra_im.draw(tela)
         mbarra3.barra_im.draw(tela)
         mbarra4.barra_im.draw(tela)
         mbarra5.barra_im.draw(tela)
         mbarra6.barra_im.draw(tela)
         mbarra7.barra_im.draw(tela)
         mbarra8.barra_im.draw(tela)
         mbarra9.barra_im.draw(tela)
         mbarra10.barra_im.draw(tela)
         mbarra11.barra_im.draw(tela)
         mbarra12.barra_im.draw(tela)
         mbarra13.barra_im.draw(tela)
         mbarra14.barra_im.draw(tela)
         mbarra15.barra_im.draw(tela)

         mbarra1.numero_im.draw(tela)
         mbarra2.numero_im.draw(tela)
         mbarra3.numero_im.draw(tela)
         mbarra4.numero_im.draw(tela)
         mbarra5.numero_im.draw(tela)
         mbarra6.numero_im.draw(tela)
         mbarra7.numero_im.draw(tela)
         mbarra8.numero_im.draw(tela)
         mbarra9.numero_im.draw(tela)
         mbarra10.numero_im.draw(tela)
         mbarra11.numero_im.draw(tela)
         mbarra12.numero_im.draw(tela)
         mbarra13.numero_im.draw(tela)
         mbarra14.numero_im.draw(tela)
         mbarra15.numero_im.draw(tela)

         rato_im.draw(tela)

         pygame.display.flip()      



if __name__=='__main__' : main()
