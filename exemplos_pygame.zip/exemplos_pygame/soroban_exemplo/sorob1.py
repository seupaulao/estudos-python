class Pedra:
      def __init__(self,valor):
          self.valor_pedra = valor
      def getValor(self):
          return self.valor_pedra


class Barra:
      def __init__(self):
          self.pedra1 = Pedra(1)
          self.pedra2 = Pedra(1)
          self.pedra3 = Pedra(1)
          self.pedra4 = Pedra(1)
          self.pedra0 = Pedra(5)
          self.barra       = [0,0,0,0,0]
  
      def mudaBarra(self, numpedra):
          if self.barra[numpedra]==1:
             return 0
          else:
             return 1
    
      def movePedra(self, numpedra):
          self.barra[numpedra] = self.mudaBarra(numpedra)
          if self.barra[numpedra] == 1:
             if (numpedra==4) and (self.barra[numpedra-1]==0):
                self.barra[3]=1
                self.barra[2]=1
                self.barra[1]=1
             elif (numpedra==3) and (self.barra[numpedra-1]==0):
                self.barra[2]=1
                self.barra[1]=1
             elif (numpedra==2) and (self.barra[numpedra-1]==0):
                self.barra[1]=1
          else:
             if (numpedra==1) and (self.barra[numpedra+1]==1):
                self.barra[2]=0
                self.barra[3]=0
                self.barra[4]=0
             elif (numpedra==2) and (self.barra[numpedra+1]==1):
                self.barra[3]=0
                self.barra[4]=0
             elif (numpedra==3) and (self.barra[numpedra+1]==1):
                self.barra[4]=0

      def valorBarra(self):
          valor_barra = 0
          if self.barra[0] == 1: valor_barra += self.pedra0.getValor()
          if self.barra[1] == 1: valor_barra += self.pedra1.getValor()
          if self.barra[2] == 1: valor_barra += self.pedra2.getValor()
          if self.barra[3] == 1: valor_barra += self.pedra3.getValor()
          if self.barra[4] == 1: valor_barra += self.pedra4.getValor()
          return valor_barra

      def zeraBarra(self):
          for i in range(5):
              self.barra[i] = 0
      
      def printBarra(self):
          print str(self.barra) +  "   Valor Barra :" + str(self.valorBarra()) 



class Abaco:
      def __init__(self, num_barras=1):
          self.barra = []
          self.barras = num_barras
          for i in range(self.barras):
              self.barra.append(Barra())
       
      def movePedraBarra(self, nbarra, npedra):
          self.barra[nbarra].movePedra(npedra)          

      def zeraAbaco(self):
          for i in range(self.barras):
              self.barra[i].zeraBarra()

      def printAbaco(self):
          for i in range(self.barras):
              self.barra[i].printBarra()
          



#barra = Barra()
#barra.printBarra()
#i = -1
#while 1:
#   i = int(raw_input("Digite qual Pedra:"))
#   if i >=5: break
#   barra.movePedra(i)
#   barra.printBarra()
x = int(raw_input("Quantas barras neste Abaco:"))   
abaco = Abaco(x)
abaco.printAbaco()
i = -1
while 1:
   j = int(raw_input("Barra : "))
   if j >= x: break
   i = int(raw_input("Pedra : "))
   if i >=5: break
   abaco.movePedraBarra(j,i)
   abaco.printAbaco()
 
