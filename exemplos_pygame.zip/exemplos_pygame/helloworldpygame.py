import pygame, sys

pygame.init()

windowSurface=pygame.display.set_mode((500,400),0,32)
pygame.display.set_caption('Ola mundo! Estou no PYGame')

black=(0,0,0)
white=(255,255,255)
red=(255,0,0)
green=(0,255,0)
blue=(0,0,255)

basicFont = pygame.font.SysFont(None, 48)

text = basicFont.render('Ola mundo', True, white, blue)

textRect = text.get_rect()

textRect.centerx = windowSurface.get_rect().centerx
textRect.centery = windowSurface.get_rect().centery

windowSurface.fill(white)

pygame.draw.polygon(windowSurface, green, ((146, 0),(291, 106), (236, 277), (56, 277), (0, 106)))

pygame.draw.line(windowSurface, blue, (60, 60), (120, 60), 4)
pygame.draw.line(windowSurface, blue, (120, 60), (60,120))
pygame.draw.line(windowSurface, blue, (60, 120), (120,120), 4)

pygame.draw.circle(windowSurface, blue, (300, 50), 20, 0)
pygame.draw.ellipse(windowSurface, red, (300, 250, 40,80),1)

# draw the text's background rectangle onto the surface
pygame.draw.rect(windowSurface, red, (textRect.left - 20,textRect.top - 20, textRect.width + 40, textRect.height + 40))

# get a pixel array of the surface
pixArray = pygame.PixelArray(windowSurface)
pixArray[480][380] = black
del pixArray

# draw the text onto the surface
windowSurface.blit(text, textRect)

# draw the window onto the screen
pygame.display.update()

# run the game loop
while True:
  for event in pygame.event.get():
    if event.type == QUIT:
      pygame.quit()
      sys.exit()



