from kivy.uix.gridlayout import GridLayout
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.scrollview import ScrollView
from kivy.core.window import Window
from kivy.app import runTouchApp

#tela boxlayout=vertical
#
# Grade
#    label 1   - texto
#    label 2   - texto
# 
# ScrollView 
#

root = BoxLayout(orientation='vertical')

layout1 = GridLayout(cols=2)
layout1.add_widget(Label(text='Idade :'))
layout1.add_widget(TextInput(multiline=False))
layout1.add_widget(Label(text='Altura   :'))
layout1.add_widget(TextInput(multiline=False))
layout1.add_widget(Label(text='Peso   :'))
layout1.add_widget(TextInput(multiline=False))

root.add_widget(layout1)
 
layout2 = BoxLayout(orientation='horizontal')
layout2.add_widget(Button(text='Comando 1',height=30))
layout2.add_widget(Button(text='Comando 2',height=30))
layout2.add_widget(Button(text='Comando 3',height=30))
root.add_widget(layout2)

layout3 = GridLayout(cols=1, spacing=10, size_hint_y=None)
layout3.bind(minimum_height=layout3.setter('height'))
for i in range(10):
    btn = Button(text=str(i), size_hint_y=None, height=40)
    layout3.add_widget(btn)

sv = ScrollView(size_hint=(1, None), size=(Window.width, Window.height*2/3))
sv.add_widget(layout3)

root.add_widget(sv)

runTouchApp(root)
