# Funcionamento kivy para layout

1. tem vários widgets padrões
2. tem layout fáceis de manipular
3. unindo o item 1 com o item 3 é possível criar widgets novos, ex: TableView
4. kivy é em python
5. há uma linguagem visual em yaml, a extensão .kv
6. porém é possível fazer tudo em .py sem necessidade do .kv
7. acho que pode atender o PROMASP no lugar do PPGD
8. para o item anterior com certeza haverá reações negativas

# Escrever em Flask

1. escrever em Flask é fácil
2. fácil pra escrever, e fácil para manter e fácil para fazer serviços [rest]
3. se os microserviços estivessem em python seria muito bom pra nós
4. porém será um PROBLEMA ao PROMASP por conta de ser em python
5. o povo pode ser reativo, e o cliente também


# OpenWhisk - serverless

1. interessante para fazer serviços em qualquer linguagem
2. pouca documentação e exemplos
3. já falaram que é melhor usar a plataforma do serpro
4. o pessoal quer trabalhar com springboot
