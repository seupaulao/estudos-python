from kivy.app import App
from kivy.uix.button import Button
from kivy.uix.boxlayout import BoxLayout


class Tela(BoxLayout):
    def __init__(self, **kwargs):
        super(Tela, self).__init__(**kwargs)
        self.orientation = 'vertical'
        self.add_widget(Button(text='Botao 1'))
        self.add_widget(Button(text='Botao 2'))
        self.add_widget(Button(text='Botao 3'))


class TestApp(App):
    def build(self):
        return Tela()

TestApp().run()
