#!/usr/bin/python

import sys
import xml.etree.ElementTree as ET

def getDadosArquivo(root):
    print "\n      Dados Arquivo       \n"
    for child in root:
        if child.tag != 'DATAELEMENTS':
           print child.tag, child.text

def getDadosVoo(root):
    print "\n      Dados do Voo        \n"
    for conjunto in root.iter('DATAELEMENTS'):
        for item in conjunto:
            if item.tag != 'PASSENGERANDCREW':
                print item.tag, item.text


def getInfoDocs(docs):
    lista = [] 
    if docs != None:
       tupla=dict()
       for item in docs:
           if item.tag == 'DOCUMENTNUMBER':
              if len(tupla) > 0:
                 lista.append(tupla)
                 tupla=dict() 
              tupla["numero"] = item.text
           if item.tag == 'DOCUMENTTYPE':
              tupla["tipo"] = item.text
           if item.tag == 'EXPIRATIONDATE':
              tupla["emissao"] = item.text
           if item.tag == 'ISSUINGSTATE':
              tupla["emissor"] = item.text
       lista.append(tupla)
    return lista    

def getBagagem(bags):
    lista = []
    if bags != None:
       for item in bags:
           lista.append(item.text)
    return lista

def getDadosPax(root):
    cont=1
    lista=[]
    for pax in root.iter('PASSENGERANDCREW'):
        temp = dict()
        temp["chave"] = cont
        temp["nome"] = pax.find('GIVENNAME').text + pax.find('SURNAME').text 
        temp["nacionalidade"] = pax.find('NATIONALITY').text
        temp["genero"] = pax.find('GENDER').text
        temp["assento"] = pax.find('SEATINGINFORMATION').text
        temp["aniversario"] = pax.find('DATEOFBIRTH').text
        temp["tipo"] = pax.find('TRAVELERSTATUS').text
        temp["embarque"] = pax.find('PLACEORIGINALEMBARKATION').text
        temp["checagem"] = pax.find('PLACECLEARENCE').text
        temp["destino"] = pax.find('PLACEONWARDFOREIGNDESTINATION').text
        temp["registro"] = pax.find('PASSENGERNAMERECORDLOCATORNUMBER').text
        temp["reserva"] = pax.find('PASSENGERRESERVATIONREFERENCE').text
        temp["unico"] = pax.find('UNIQUEPASSENGERREFERENCE').text
        temp["agencia"] = pax.find('GOVERNMENTAGENCYREFERENCE').text
        temp["documentos"] = getInfoDocs(pax.find('INFODOCS'))
        temp["bagagens"] = getBagagem(pax.find('BAGGAGEINFORMATION'))
        lista.append(temp)
        cont += 1
    return lista 

def imprimeLista(lista):
   for pax in lista:
      print pax["chave"], pax["nome"], pax["nacionalidade"], pax["genero"]

def listarPax(lista, posicao):
   print "entrou"
   for pax in lista:
      if pax["chave"] == posicao:
         print "\n          Dados do Passageiro/Tripulante \n"
         print pax["chave"], pax["nome"], pax["nacionalidade"], pax["genero"] 
         print "Aniversario: ", pax["aniversario"]
         print "Tipo Pax: ", pax["tipo"], "   Assento: ", pax["assento"]
         print "Aero Embarque: ", pax["embarque"], "  Aero Desembarque: ", pax["destino"], "  Aero Check:", pax["checagem"]
         print "Registro: " , pax["registro"], "  Reserva: ", pax["reserva"]
         print "Agencia: " , pax["agencia"], "  ID: ", pax["unico"]
         documentos = pax["documentos"]
         bagagens = pax["bagagens"]
         if len(documentos) > 0:
            print "\n          Documento de Viagem \n"
            for doc in documentos:
                print "Tipo         : ", doc["tipo"]     
                print "Numero       : ", doc["numero"]     
                print "Pais Emissor : ", doc["emissor"]     
                print "Dt Emissao   : ", doc["emissao"]     
         if len(bagagens) > 0:
            print "\n          Bagagem \n"
            for doc in bagagens:
                print "Etiqueta         : ", doc     
         
         
def main():
    
    tree = ET.parse(sys.argv[1])
    root=tree.getroot()
    getDadosArquivo(root)
    getDadosVoo(root)
    pax = getDadosPax(root)
    opcao=-1
    while opcao!=0:
        print "\n"
        print "\n      Passageiros e Tripulantes    \n"
        imprimeLista(pax)
        print 
        opcao=int(raw_input("Escolha um tripulante: "))
        if not (opcao < 0 or opcao > len(pax)):
           listarPax(pax, opcao)
        else:
           print "\n   ---> Opcao Invalida <--- \n"
    print "\n\n Volte Sempre!\n"

main()
