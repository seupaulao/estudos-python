#!/usr/bin/python

from Tkinter import *

class Sisbraipy:

    def __init__(self, root):
        self.raiz = root
        self.raiz.title('SISBRAIPy - API Reader and FactSheet generator')
        self.criarComponentes()
   
    def criarComponentes(self):
        self.fr1 = Frame(self.raiz)
        self.fr1.pack()
        self.fr2 = Frame(self.raiz)
        self.fr2.pack()
        self.fr3 = Frame(self.raiz)
        self.fr3.pack()
        self.fr4 = Frame(self.raiz)
        self.fr4.pack()
        self.fr5 = Frame(self.raiz)
        self.fr5.pack()
 
        self.b1 = Button(self.fr1, text='Ler Arquivo', command=self.loadArquivo)
        self.b1.pack(side=LEFT)
        self.b2 = Button(self.fr1, text='Ler Pasta',  command=self.loadPasta)
        self.b2.pack(side=LEFT)
        
        self.lbmsg = Listbox(self.fr2)
        self.lbmsg.bind("<Button-1>",self.selecionaPax)
        self.lbmsg.pack()

        self.lbpax = Listbox(self.fr3)
        self.lbpax.pack()

        self.check = Checkbutton(self.fr4, text='Gerar Saida FactSheet')
        self.check.pack()
 
        self.b3 = Button(self.fr5, text='Gravar Mensagem Selecionada', command=self.saveMsg)
        self.b3.pack(side=LEFT)
        self.b4 = Button(self.fr5, text='Gravar Todas as Mensagens', command=self.saveAllMsg)
        self.b4.pack(side=LEFT)

        self.fr6 = Frame(self.raiz)
        self.fr6.pack()

        self.bSair = Button(self.fr6, text = 'Sair', font=('Verdana', 12, 'bold'), command=self.sair)
        self.bSair.pack()

    def loadArquivo(self):
        print 'carregar um arquivo somente'

    def loadPasta(self):
        print 'carregar todos os arquivos de uma pasta'

    def saveMsg(self):
        print 'salvar mensagem selecionada'

    def saveAllMsg(self):
        print 'salvar todas as mensagens'
   
    def sair(self):
        print 'sair do programa'
        self.raiz.quit()

    def selecionaPax(self, event):
        print 'cliquei na lista de pax' 


instancia=Tk()
Sisbraipy(instancia)
instancia.mainloop()

