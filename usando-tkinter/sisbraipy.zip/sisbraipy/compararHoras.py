import os
import sys

def calcularSegundo(data):
    v = data.split(" ")
    hora = v[2]
  #  print hora
    vhora = hora.split(":")
    return int(vhora[0])*3600 + int(vhora[1])*60 + int(vhora[2])

if len(sys.argv) <= 2:
   print 'Mod de usar : python compararHoras.py arquivo colunadata colunanome'
else: 
   arquivo = sys.argv[1]
   colunadata = int(sys.argv[2])
   colunanome = int(sys.argv[3])
   
   print arquivo
   print colunadata
   print colunanome
   #extrai as colunas dos arquivos
   vetor=[]
   arq = open(arquivo,'r')
   for linha in arq.readlines():
       vet = linha.split('|') 
       if len(vet)>1:
          tmp=[]
          tmp.append(vet[colunadata-1])
          tmp.append(vet[colunanome-1])
          vetor.append(tmp)
   arq.close()    

   print len(vetor)
   
   #realiza a comparacao
   c = 0
   maximo = 0
 #  minimo = 0
   nomemaximo = ""
   #nomeminimo = ""
   ultimotempo = 0
   for item in vetor:
       tempo = calcularSegundo(item[0])
       nome = item[1]
       if ultimotempo==0:
          nomemaximo = nome
    #      nomeminimo = nome
       elif ultimotempo != 0:
          dif = tempo - ultimotempo
          if dif > maximo:
             maximo = dif
             nomemaximo = nome
    #      if dif <= minimo:
    #         minimo = dif
    #         nomeminimo = nome 
       ultimotempo = tempo

   print 'Tempo maximo segundos= ',maximo, 'Arquivo : ', nomemaximo
#   print 'Tempo minimo = ',minimo, 'Arquivo : ', nomeminimo



           


