#!/usrbin/pyhton

import zipfile
import glob
import os.path
import sys

class Zipador(object):

   def __init__(self,proc,pas):
       self.pasta = pas
       self.processamento = proc

   def processar(self):
       if self.processamento == 1 :
          self.verPasta()
       elif self.processamento == 2:
          self.compactarPasta1('arquivo')
       elif self.processamento == 3:
          self.compactarPastaM('arquivo')

   def verPasta(self):
          for arq in sorted(glob.glob(self.pasta+'/*')):
              print arq 

   def compactarPasta1(self,nome):
          zip1 = zipfile.ZipFile(nome,'w',zipfile.ZIP_DEFLATED)
          for arq in glob.glob(self.pasta+'/*.TXT') 
              zip1.write(self.pasta + "/" + arq)
          zip1.close()

   def compactarPastaM(self,nome): 
          print "zipar em varios arquivos"


print "------Zipador------\n"
print "Modo de Usar : python zipPasta.py arg pasta\n"
print "1. listar os arquivos em uma pasta"
print "2. compactar todos os arquivos da pasta em 1 arquivo.zip"
print "3. compactar todos os arquivos da pasta em 1 arquivo zip por dia\n"


if len(sys.argv) > 2:
   op = int(sys.argv[1])
   pa = sys.argv[2]
   zipador = Zipador(op,pa)
   zipador.processar()    
   
