#!/usr/bin/python

import detalharApi
import glob
import sys

###########################
#1. processar todos os arquivos buscando separar os passageiros dos voos no seguinte formato
#   voo
#   data e hora de partida
#   data e hora de chegada
#   aeroporto origem
#   aeroporto destino
#   nome
#   data de nascimento
#   peso
#   unidade
#2. destacar somente os passageiros que contem a informacao MEA(Separador)WT
#3. gravar a saida num CSV e solicitar a SUPCD que ao final do processamento envie o resultado para DEFLA/DE301  
###########################
#ls -tr | xargs egrep -li "MEA.WT"
###########################
def salvarPosicao(diretorio, na, ual, cont):
   try:
      arq=open(diretorio+'/savepoint.dat','w')
      arq.write(str(na)+'|'+ual+'|'+str(cont))
      arq.close()
   except:
      print 'erro ao salvar arquivo de posicao'

def recuperarPosicao(diretorio):
   try:
      lista = []
      arq=open(diretorio+'/savepoint.dat','r')
      valor = arq.read()
      lvalor = valor.split('|')
      lista.append(int(lvalor[0]))
      lista.append(str(lvalor[1]))
      lista.append(int(lvalor[2]))
      arq.close() 
      return lista
   except:
      return [0,'',0]     

def getValor(sdir, item):
   a=item
   b=a.split('/')
   a=b[len(b)-1]
   a=a[0:len(a)-4]
   a=a[18:]
   l=a.split('-')
   svalor = reduce(lambda x,y: x+y, l)
   try:
      return int(svalor)
   except:
      l=a.split('_')
      svalor = reduce(lambda x,y: x+y, l)
      return int(svalor)


valormascara=20151122000000000
numero_arquivos = 0
ultimo_arquivo_lido = ''
contador = 0
diretorio="."
try:
   if len(sys.argv) > 1:
      diretorio=sys.argv[1]
   lista = glob.glob(diretorio+'/*.TXT')
   listap = recuperarPosicao(diretorio) 
   numero_arquivos = listap[0]
   ultimo_arquivo_lido = listap[1]
   contador = listap[2]
   numero_arquivos = len(lista)
   for item in lista:
       if getValor(diretorio + '/', item) <= valormascara:
          continue  
       contador = contador + 1
       ultimo_arquivo_lido = item[len(diretorio+'/'):]
       parser = detalharApi.ParserAPI(item)
       parser.lerarquivo()
       parser.tratarcadeia()
       parser.atualizarcaracteres()
       if parser.existeStringInArquivo(parser.getStringMeaPeso()):
          parser.iniciarParser()
          for pas in parser.passageiros:
              if len(pas.pesobagagem) > 0 :
                 print parser.mensagem["identificacao"], "|", parser.mensagem["dataDecolagem"], "|", parser.mensagem["horaDecolagem"], "|", parser.mensagem["dataAterrissagem"], "|", parser.mensagem["horaAterrissagem"], "|", parser.mensagem["ultimoAeroportoDecolagem"], "|", parser.mensagem["primeiroAeroportoAterrissagem"],"|",pas.nome,"|",pas.datanascimento,"|",pas.pesobagagem,"|",pas.unidadebagagem,"|",pas.etiquetabagagem
finally:
   print 'FINALIZANDO PROCESSAMENTO'    
   salvarPosicao(diretorio, numero_arquivos, ultimo_arquivo_lido, contador)
       
 
