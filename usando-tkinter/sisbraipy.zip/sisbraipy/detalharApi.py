#!/usr/bin/python

import os

class Passageiro:
  def __init__(self):
      self.nome = ""
      self.endereco=""
      self.cidade=""
      self.uf=""
      self.cep=""
      self.pais=""
      self.istransito=0
      self.ispax=0
      self.aeroportoprocedimentomigracao=""
      self.paisresidencia=""
      self.aeroportoinicioviagem=""
      self.aeroportofinalviagem=""
      self.paisemissordocumento=""
      self.datanascimento=""
      self.dataexpiracaodocumento=""
      self.sexo=""
      self.nacionalidade=""
      self.numeromensagempnr=""
      self.assento=""
      self.referenciaunica=""
      self.tipodocumento=""
      self.numerodocumento=""
      self.codigogei=""
      self.indicadorgei=""
      self.quantidadebagagem=""
      self.pesobagagem=""
      self.unidadebagagem=""
      self.etiquetabagagem=""
  def setNome(self, valor):
      self.nome=valor
  def setEndereco(self, valor):
      self.endereco=valor
  def setCidade(self, valor):
      self.cidade=valor
  def setUf(self, valor):
      self.uf=valor
  def setCep(self, valor):
      self.cep=valor
  def setPais(self, valor):
      self.pais=valor
  def setIsTransito(self, valor):
      self.istransito=valor
  def setIsPax(self, valor):
      self.ispax=valor
  def setAeroportoProcedimentoMigracao(self, valor):
      self.aeroportoprocedimentomigracao=valor
  def setPaisResidencia(self, valor):
      self.paisresidencia=valor
  def setAeroportoInicioViagem(self, valor):
      self.aeroportoinicioviagem=valor
  def setAeroportoFinalViagem(self, valor):
      self.aeroportofinalviagem=valor
  def setPaisEmissorDocumento(self, valor):
      self.paisemissordocumento=valor
  def setDataNascimento(self, valor):
      self.datanascimento=valor
  def setDataExpiracaoDocumento(self, valor):
      self.dataexpiracaodocumento=valor
  def setSexo(self, valor):
      self.sexo=valor
  def setNacionalidade(self, valor):
      self.nacionalidade=valor
  def setNumeroMensagemPnr(self, valor):
      self.numeromensagempnr=valor
  def setAssento(self, valor):
      self.assento=valor
  def setReferenciaUnica(self, valor):
      self.referenciaunica=valor
  def setTipoDocumento(self, valor):
      self.tipodocumento=valor
  def setNumeroDocumento(self, valor):
      self.numerodocumento=valor
  def setCodigoGei(self, valor):
      self.codigogei=valor
  def setIndicadorGei(self, valor):
      self.indicadorgei=valor
  def setUnidadebagagem(self, valor):
      self.unidadebagagem=valor
  def setPesobagagem(self, valor):
      self.pesobagagem=valor
  def setQuantidadebagagem(self, valor):
      self.quantidadebagagem=valor


class ParserAPI:

  def __init__(self,nomearquivo):
     self.caractereSeparadorComponenteElementoDado = ":"
     self.caractereSeparadorElementoDado = "\\+"
     self.caractereMarcadorDecimal = "\\."
     self.caractereMarcadorLancamento = "?"
     self.caractereSeparadorRepeticao = "\\*"
     self.caractereMarcadorFinalSegmento = "\'"
     self.nomearquivo = nomearquivo
     self.mensagem = dict()
     self.cadeia = ""
     self.vetorElementos=[]
     self.passageiros=[]

  def setCadeia(self, cadeianova):
     self.cadeia = cadeianova

  def zerar(self):
     self.caractereSeparadorComponenteElementoDado = ":"
     self.caractereSeparadorElementoDado = "\\+"
     self.caractereMarcadorDecimal = "\\."
     self.caractereMarcadorLancamento = "?"
     self.caractereSeparadorRepeticao = "\\*"
     self.caractereMarcadorFinalSegmento = "\'"
     self.mensagem = dict()
     self.cadeia = ""
     self.vetorElementos=[]
     self.passageiros=[]

  def lerarquivo(self):
     f = open(self.nomearquivo,'r')
     saida = ""
     for frase in f.readlines():
        saida = saida + frase 
     f.close()
     self.cadeia=saida
    
  def imprimir(self):
     print
     print "Quantidade de passageiros: ", self.mensagem["quantidadePassageiros"]
     print "Voo:", self.mensagem["identificacao"]
     print "Data Decolagem : ", self.mensagem["dataDecolagem"], " Hora Decolagem: ", self.mensagem["horaDecolagem"] 
     print "Data Aterrisagem : ", self.mensagem["dataAterrissagem"], " Hora Aterrissagem: ", self.mensagem["horaAterrissagem"] 
     print "Origem : ", self.mensagem["ultimoAeroportoDecolagem"], " Destino: ", self.mensagem["primeiroAeroportoAterrissagem"] 
     print "Passageiro(1) ou Tripulante(0) ? ", self.mensagem["ispax"]
     print

     for pas in self.passageiros:
        print  pas.nome, pas.datanascimento, pas.numerodocumento, pas.tipodocumento , "Bagagem: ",pas.quantidadebagagem, pas.pesobagagem, pas.unidadebagagem, pas.etiquetabagagem

  def pegarValor(self, vetor, parametro):
     try:
       return vetor[parametro]
     except:
       return None

  def tratarNomeProprio(self, nome):
     lista = nome.split(self.caractereSeparadorComponenteElementoDado)
     novo=""
     for no in lista[::-1]:
         novo = novo + no + " "
     # print novo[0:len(novo)-1]
     return novo[0:len(novo)-1]

  def tratarcadeia(self):
     self.cadeia=self.cadeia.replace("\n","")
     self.cadeia=self.cadeia.replace("\r","")
     if self.cadeia.find("UNA") > -1 :
        self.cadeia = self.cadeia[self.cadeia.find("UNA"):];

  def tratarMetaCaracteresDeExpressoesRegulares(self, caractere):
     retorno = caractere;
     if (".[]^$()*,+|".find(caractere) > -1):
       retorno = caractere
     return retorno

  def atualizarcaracteres(self):  
     if self.cadeia[0:3] == "UNA": 
        self.caractereSeparadorComponenteElementoDado = self.tratarMetaCaracteresDeExpressoesRegulares(self.cadeia[3])
        self.caractereSeparadorElementoDado = self.tratarMetaCaracteresDeExpressoesRegulares(self.cadeia[4])
        self.caractereMarcadorDecimal = self.tratarMetaCaracteresDeExpressoesRegulares(self.cadeia[5])
        self.caractereMarcadorLancamento = self.tratarMetaCaracteresDeExpressoesRegulares(self.cadeia[6])
        self.caractereSeparadorRepeticao = self.tratarMetaCaracteresDeExpressoesRegulares(self.cadeia[7])
        self.caractereMarcadorFinalSegmento = self.tratarMetaCaracteresDeExpressoesRegulares(self.cadeia[8])

  def getStringMeaPeso(self):
     return "MEA" + self.caractereSeparadorElementoDado + "WT"

  def existeStringInArquivo(self,string):
     if string in self.cadeia:
        return True
     else:
        return False
  
  def iniciarParser(self):
     self.vetorElementos = self.cadeia.split(self.caractereMarcadorFinalSegmento)
     for segmento in self.vetorElementos: 
         self.processarSegmento(segmento)

  def processarSegmento(self, segmento):
     elementos = segmento.split(self.caractereSeparadorElementoDado)
     tipo = elementos[0]
     objPassageiro = None
     indicePassageiroAtual = len(self.passageiros) - 1
     bagagem=None
     if tipo=="UNB":
        componentes = self.pegarValor(elementos,4).split(self.caractereSeparadorComponenteElementoDado)
        self.mensagem["data"] = self.pegarValor(componentes,0)
        self.mensagem["hora"] = self.pegarValor(componentes,1)
        self.mensagem["remetente"] = self.pegarValor(elementos,2)
        self.mensagem["controleintercambio"] = self.pegarValor(elementos,5)
        self.mensagem["nomecompanhiaaerea"] = self.pegarValor(elementos,2)
     elif tipo == "UNG":
        self.mensagem["grupofuncional"] = self.pegarValor(elementos,5)
        componentes = self.pegarValor(elementos,2).split(self.caractereSeparadorComponenteElementoDado)
        self.mensagem["sigla"] = self.pegarValor(elementos,1)
     elif tipo == "UNH":
        self.mensagem["numerounh"] = self.pegarValor(elementos,1)
     elif tipo == "BGM":
        if self.pegarValor(elementos,1) == "745":
           self.mensagem["ispax"] = 1
        else:
           self.mensagem["ispax"] = 0
     elif tipo == "NAD":
        if self.pegarValor(elementos,1) == "MS":
           self.mensagem["responsavel"] = self.tratarNomeProprio( self.pegarValor( elementos, 4 ) )
        else:
           objPassageiro = Passageiro()
	   objPassageiro.setNome(self.tratarNomeProprio(self.pegarValor(elementos, 4)));
           objPassageiro.setEndereco(self.pegarValor(elementos, 5));
           objPassageiro.setCidade(self.pegarValor(elementos, 6));
           objPassageiro.setUf(self.pegarValor(elementos, 7));
           objPassageiro.setCep(self.pegarValor(elementos, 8));
           objPassageiro.setPais(self.pegarValor(elementos, 9));
           if self.pegarValor(elementos,1) == "DDT":
              objPassageiro.setIsPax(0)
              objPassageiro.setIsTransito(1)
           elif self.pegarValor(elementos,1) == "DDU":
              objPassageiro.setIsPax(1)
              objPassageiro.setIsTransito(1)
           elif self.pegarValor(elementos,1) == "FL":
              objPassageiro.setIsPax(1)
              objPassageiro.setIsTransito(0)
           elif self.pegarValor(elementos,1) == "FM":
              objPassageiro.setIsPax(0)
              objPassageiro.setIsTransito(0)
           self.passageiros.append(objPassageiro)
     elif tipo == "COM":
        for i in range(len(elementos)):
          componentes = self.pegarValor(elementos,i).split(self.caractereSeparadorComponenteElementoDado)
          if self.pegarValor(componentes, 1) == "TE":
             self.mensagem["telefoneresponsavel"] = self.pegarValor(componentes,0)
          elif self.pegarValor(componentes, 1) == "FX":
             self.mensagem["faxresponsavel"] = self.pegarValor(componentes,0)
          elif self.pegarValor(componentes, 1) == "EM":
             self.mensagem["emailresponsavel"] = self.pegarValor(componentes,0)
     elif tipo == "TDT":
        if self.pegarValor(elementos, 1) == "20":
           self.mensagem["chegadasaida"] = 1
        else:
           self.mensagem["chegadasaida"] = 0
        self.mensagem["identificacao"] =  self.pegarValor(elementos, 2) 
     elif tipo == "LOC":
        if self.pegarValor(elementos, 1)=="87": 
           self.mensagem["primeiroAeroportoAterrissagem"] = self.pegarValor(elementos, 2)
        elif self.pegarValor(elementos, 1)=="92":
           self.mensagem["proximoAeroportoDestino"]=self.pegarValor(elementos, 2)
        elif self.pegarValor(elementos, 1)=="125":
           self.mensagem["ultimoAeroportoDecolagem"]=self.pegarValor(elementos, 2)
        elif self.pegarValor(elementos, 1)=="130":
           self.mensagem["aeroportoDestinacaoFinal"]=self.pegarValor(elementos, 2)
        elif self.pegarValor(elementos, 1)=="22":
           if indicePassageiroAtual > -1: 
              self.passageiros[indicePassageiroAtual].setAeroportoProcedimentoMigracao(self.pegarValor(elementos, 2))
        elif self.pegarValor(elementos, 1)=="174":
           if indicePassageiroAtual > -1: 
              self.passageiros[indicePassageiroAtual].setPaisResidencia(self.pegarValor(elementos, 2))
        elif self.pegarValor(elementos, 1)=="178":
           if indicePassageiroAtual > -1: 
              self.passageiros[indicePassageiroAtual].setAeroportoInicioViagem(self.pegarValor(elementos, 2))
        elif self.pegarValor(elementos, 1)=="179":
           if indicePassageiroAtual > -1: 
              self.passageiros[indicePassageiroAtual].setAeroportoFinalViagem(self.pegarValor(elementos, 2))
        elif self.pegarValor(elementos, 1)=="91":
           if indicePassageiroAtual > -1: 
              self.passageiros[indicePassageiroAtual].setPaisEmissorDocumento(self.pegarValor(elementos, 2))
     elif tipo == "DTM":
        componentes = self.pegarValor(elementos, 1).split(self.caractereSeparadorComponenteElementoDado)		
        if self.pegarValor(componentes, 0) == "189":
           self.mensagem["dataDecolagem"] = self.pegarValor(componentes, 1)[0:6]
           self.mensagem["horaDecolagem"] = self.pegarValor(componentes, 1)[6:10]
        elif self.pegarValor(componentes, 0) == "232":
            self.mensagem["dataAterrissagem"] = self.pegarValor(componentes, 1)[0:6]
            self.mensagem["horaAterrissagem"] = self.pegarValor(componentes, 1)[6:10]
        elif self.pegarValor(componentes, 0) == "329":
            if indicePassageiroAtual > -1:
               self.passageiros[indicePassageiroAtual].setDataNascimento(self.pegarValor(componentes, 1))
        elif self.pegarValor(componentes, 0) == "36": 
            if indicePassageiroAtual > -1: 
               self.passageiros[indicePassageiroAtual].setDataExpiracaoDocumento(self.pegarValor(componentes, 1))
     elif tipo == "ATT":
        if indicePassageiroAtual > -1: 
           self.passageiros[indicePassageiroAtual].setSexo(self.pegarValor(elementos, 3))
     elif tipo == "NAT":
        if indicePassageiroAtual > -1: 
           self.passageiros[indicePassageiroAtual].setNacionalidade(self.pegarValor(elementos, 2));
     elif tipo == "RFF":
        componentes = self.pegarValor(elementos, 1).split(self.caractereSeparadorComponenteElementoDado)
        if self.pegarValor(componentes, 0) == "AVF":
	   if indicePassageiroAtual > -1: 
              self.passageiros[indicePassageiroAtual].setNumeroMensagemPnr(self.pegarValor(componentes, 1))
	elif self.pegarValor(componentes, 0) == "ABO":
           if indicePassageiroAtual > -1: 
              self.passageiros[indicePassageiroAtual].setReferenciaUnica(self.pegarValor(componentes, 1))
	elif self.pegarValor(componentes, 0) =="SEA":
           if indicePassageiroAtual > -1: 
              self.passageiros[indicePassageiroAtual].setAssento(self.pegarValor(componentes, 1))
     elif tipo == "GEI":
	if indicePassageiroAtual > -1: 
           self.passageiros[indicePassageiroAtual].setCodigoGei(self.pegarValor(elementos, 1))
           self.passageiros[indicePassageiroAtual].setIndicadorGei(self.pegarValor(elementos, 2))
     elif tipo == "MEA":
        componentes = self.pegarValor(elementos, 3).split(self.caractereSeparadorComponenteElementoDado)
	if indicePassageiroAtual > -1: 
           if self.pegarValor(elementos,1) == "CT":
              self.passageiros[indicePassageiroAtual].setQuantidadebagagem(self.pegarValor(componentes, 1))
           if self.pegarValor(elementos,1) == "WT":
              self.passageiros[indicePassageiroAtual].setUnidadebagagem(self.pegarValor(componentes, 0))
              self.passageiros[indicePassageiroAtual].setPesobagagem(self.pegarValor(componentes, 1))
     elif tipo == "FTX":
        componentes = self.pegarValor(elementos, 4)
        if indicePassageiroAtual > -1:
           self.passageiros[indicePassageiroAtual].etiquetabagagem = self.passageiros[indicePassageiroAtual].etiquetabagagem + componentes + ","
     elif tipo == "DOC":
        componentes = self.pegarValor(elementos, 1).split(self.caractereSeparadorComponenteElementoDado)		
        if indicePassageiroAtual > -1:
           self.passageiros[indicePassageiroAtual].setTipoDocumento(self.pegarValor(componentes, 0));
           self.passageiros[indicePassageiroAtual].setNumeroDocumento(self.pegarValor(elementos, 2));
     elif tipo == "CNT":
        componentes = self.pegarValor(elementos, 1).split(self.caractereSeparadorComponenteElementoDado);
        if self.pegarValor(componentes, 0) == "42":
           self.mensagem["quantidadePassageiros"] = self.pegarValor(componentes, 1);
        elif self.pegarValor(componentes, 0) == "41":
           self.mensagem["quantidadeTripulantes"] = self.pegarValor(componentes, 1);


# def mainGravarPastaBancoLocal():  
#       pasta = sys.argv[1]
#       f = [] 
#       for (dirpath, dirname, filenames) in os.walk(pasta): 
#           f.extend(filenames)
#           break
#       for arq in f:
#           arquivo=dirpath + arq
#           parser = ParserAPI(arquivo)
#           parser.lerarquivo()
#           parser.tratarcadeia()
#           parser.atualizarcaracteres()
#           parser.iniciarParser()
#           banco = Banco(parser.mensagem, parser.passageiros)
#           banco.persistir()
     
# def mainDetalharArquivo():
#       arquivo = None
#       try:  
#          arquivo = sys.argv[1]
#       except:
#          arquivo = None  
#       if arquivo is None:
#          print "Nao foi informado um arquivo como parametro"
#       else:
#          parser = ParserAPI(arquivo)
#          parser.lerarquivo()
#          parser.tratarcadeia()
#          parser.atualizarcaracteres()
#          parser.iniciarParser()
#          parser.imprimir()

