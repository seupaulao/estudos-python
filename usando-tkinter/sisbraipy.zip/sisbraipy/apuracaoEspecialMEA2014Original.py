#!/usr/bin/python

import detalharApi
import glob
import sys

###########################
#1. processar todos os arquivos buscando separar os passageiros dos voos no seguinte formato
#   voo
#   data e hora de partida
#   data e hora de chegada
#   aeroporto origem
#   aeroporto destino
#   nome
#   data de nascimento
#   peso
#   unidade
#2. destacar somente os passageiros que contem a informacao MEA(Separador)WT
#3. gravar a saida num CSV e solicitar a SUPCD que ao final do processamento envie o resultado para DEFLA/DE301  
###########################
#ls -tr | xargs egrep -li "MEA.WT"
###########################
numero_arquivos = 0
ultimo_arquivo_lido = ''
contador = 0
diretorio="."
if len(sys.argv) > 1:
   diretorio=sys.argv[1]
lista = glob.glob(diretorio+'/*.TXT')
for item in lista:
    parser = detalharApi.ParserAPI(item)
    parser.lerarquivo()
    parser.tratarcadeia()
    parser.atualizarcaracteres()
    if parser.existeStringInArquivo(parser.getStringMeaPeso()):
       parser.iniciarParser()
       for pas in parser.passageiros:
           if len(pas.pesobagagem) > 0 :
              print parser.mensagem["identificacao"], "|", parser.mensagem["dataDecolagem"], "|", parser.mensagem["horaDecolagem"], "|", parser.mensagem["dataAterrissagem"], "|", parser.mensagem["horaAterrissagem"], "|", parser.mensagem["ultimoAeroportoDecolagem"], "|", parser.mensagem["primeiroAeroportoAterrissagem"],"|",pas.nome,"|",pas.datanascimento,"|",pas.pesobagagem,"|",pas.unidadebagagem
       
 
