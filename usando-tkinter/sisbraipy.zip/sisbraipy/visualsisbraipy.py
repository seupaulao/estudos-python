#!/usr/bin/python

from Tkinter import *
import detalharApi
import gravarApi
import tkFileDialog
import pegarPasta
import os.path
from os import walk
import tkMessageBox

class Sisbraipy:

    def __init__(self, root):
        self.raiz = root
        self.raiz.title('SISBRAIPy - API Reader and FactSheet generator')
        self.parsers = []
        self.criarComponentes()
   
    def criarComponentes(self):
        self.fr1 = Frame(self.raiz)
        self.fr1.pack()
        self.fr2 = Frame(self.raiz)
        self.fr2.pack()
        self.fr3 = Frame(self.raiz)
        self.fr3.pack()
        self.fr5 = Frame(self.raiz)
        self.fr5.pack()
 
        self.b1 = Button(self.fr1, text='Ler Arquivo', command=self.loadArquivo)
        self.b1.pack(side=LEFT)
        self.b2 = Button(self.fr1, text='Ler Pasta',  command=self.loadPasta)
        self.b2.pack(side=LEFT)
        
        self.lbmsg = Listbox(self.fr2,width=200)
        self.lbmsg.bind("<ButtonRelease>",self.selecionaPax)
        self.lbmsg.pack()

        self.lbpax = Listbox(self.fr3,width=200)
        self.lbpax.pack()

        self.b4 = Button(self.fr5, text='Gravar Todas as Mensagens', command=self.saveAllMsg)
        self.b4.pack(side=LEFT)

        self.fr6 = Frame(self.raiz)
        self.fr6.pack()

        self.bSair = Button(self.fr6, text = 'Sair', font=('Verdana', 12, 'bold'), command=self.sair)
        self.bSair.pack()

    def loadArquivo(self):
        #arquivo = "BR_PNRHUB_API_REC_2015-08-26-01-34-44-446.TXT"
        arquivo = tkFileDialog.askopenfilename(title='Selecione um arquivo API...')
        if len(arquivo) > 0:
           self.carregarParser(arquivo)
           self.carregarmsg()

    def carregarParser(self,filename):
        parser=detalharApi.ParserAPI(filename)
        parser.lerarquivo()
        parser.tratarcadeia()
        parser.atualizarcaracteres()
        parser.iniciarParser()
        self.parsers.append(parser)

    def carregarParserFolder(self, path):
        if os.path.exists(path) and os.path.isdir(path):
           arqs=[]
           for (_,_,files) in walk(path):
               arqs.extend(files)
               break
           for item in arqs:
               valor = path + "/" + item
               # print valor
               self.carregarParser(valor)
    def zeros(self, valor, qte):
        return (qte-len(str(valor)))*str(0) + str(valor) + ". "

    def carregarmsg(self):
        if self.lbmsg.size()>0:
           self.lbmsg.delete(0, self.lbmsg.size()) 
        cont = 1
        for parser in self.parsers:
           elemento = ""
           qtepax = self.isnull(parser.pegarValor(parser.mensagem,"quantidadePassageiros"))
           ident = self.isnull(parser.pegarValor(parser.mensagem,"identificacao"))
           partida = self.isnull(parser.pegarValor(parser.mensagem,"dataDecolagem"))
           if len(qtepax)>0 and len(ident)>0 and len(partida)>0:
              elemento = elemento + self.zeros(cont,3) + "   "
              elemento = elemento + " qte:     " + qtepax
              elemento = elemento + " voo:     " + ident
              elemento = elemento + " partida: " + partida + " " + parser.mensagem["horaDecolagem"]
              elemento = elemento + " chegada: " + parser.mensagem["dataAterrissagem"] + " " + parser.mensagem["horaAterrissagem"]
              elemento = elemento + " origem:  " + parser.mensagem["ultimoAeroportoDecolagem"]
              elemento = elemento + " destino  " + parser.mensagem["primeiroAeroportoAterrissagem"]
              if str(parser.mensagem["ispax"]=="1"):
                 elemento = elemento + " pax?     " + "SIM"
              else:
                 elemento = elemento + " pax?     " + "NAO"
    
              self.lbmsg.insert(self.lbmsg.size(), elemento)  
              cont += 1
        

    def loadPasta(self):
        instancia2 = Tk()
        app = pegarPasta.GetFolder(instancia2)
        instancia2.mainloop()
        pathfiles = app.pathatual
        instancia2.destroy()
        self.parsers=[]
        self.raiz.configure(cursor='clock')
        self.carregarParserFolder(pathfiles)
        self.carregarmsg()
        self.raiz.configure(cursor='left_ptr')

    def saveAllMsg(self):
        self.raiz.configure(cursor='clock')
        for parser in self.parsers:
            banco = gravarApi.Banco(parser.mensagem, parser.passageiros)
            banco.persistir()
        tkMessageBox.showinfo(title='Informacao', message='Gravacao efetuada com sucesso')
        self.raiz.configure(cursor='left_ptr')
   
    def sair(self):
        print 'sair do programa'
        self.raiz.quit()

    def isnull(self,valor):
        try:
           if valor==None:
              return ""
           else:
              return valor
        except:
           return ""

    def selecionaPax(self, event):
        if self.lbmsg.size()>0:
           item = self.lbmsg.curselection() 
           if item != None or len(a)>0:
              parser = self.parsers[int(item[0])]
              if self.lbpax.size()>0:
                 self.lbpax.delete(0, self.lbpax.size())
              for pas in parser.passageiros:
                 elemento = self.isnull(pas.nome) + "  " + self.isnull(pas.datanascimento) + "  " + self.isnull(pas.numerodocumento) + "  " + self.isnull(pas.tipodocumento) + " Bagagem: " + self.isnull(pas.quantidadebagagem) + "  " + self.isnull(pas.pesobagagem) + "  " + self.isnull(pas.unidadebagagem) + "  " + self.isnull(pas.etiquetabagagem)
                 self.lbpax.insert(self.lbpax.size(), self.isnull(elemento))
                   


instancia=Tk()
Sisbraipy(instancia)
instancia.mainloop()

