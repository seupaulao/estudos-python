drop table tbsequencia;
drop table tbmensagem;
drop table tbpassageiro;

CREATE TABLE tbsequencia
(
   id INTEGER,
   valor INTEGER
);

insert into tbsequencia(id,valor) values (1, 1);
insert into tbsequencia(id,valor) values (2, 1);

CREATE TABLE tbmensagem(
   id TEXT PRIMARY KEY,
   dtproc TEXT, 
   data TEXT,
   hora TEXT,
   remetente TEXT,
   controleintercambio TEXT,
   nomecompanhiaaerea TEXT,
   grupofuncional TEXT,
   sigla TEXT,
   numerounh TEXT,
   ispax integer,
   responsavel text,
   telefoneresponsavel text,
   faxresponsavel text,
   emailresponsavel,
   chegadasaida integer,
   identificacaovoo text,
   primeiroaeroportoaterrissagem text,
   proximoaeroportodestino text,
   ultimoaeroportodecolagem text,
   aeroportodestinacaofinal text,
   datadecolagem text,
   dataaterrissagem text,
   horadecolagem text,
   horaaterrissagem text,
   quantidadepassageiros integer,
   quantidadetripulantes integer
);


CREATE TABLE tbpassageiro(
   mensagemid text,
   quantidadebagagem text,
   pesobagagem text,
   unidadebagagem text,
   etiquetabagagem text,
   nome  text,
   endereco text,
   cidade text,
   uf text,
   cep text,
   pais text,
   istransito integer,
   ispax  integer,
   aeroportoprocedimentomigracao text,
   paisresidencia text,
   aeroportoinicioviagem text,
   aeroportofinalviagem text,
   paisemissordocumento text,
   datanascimento text,
   dataexpiracaodocumento text,
   sexo text,
   nacionalidade text,
   numeromensagempnr text,
   assento text,
   referenciaunica text,
   tipodocumento text,
   numerodocumento text,
   codigogei text,
   indicadorgei text,
   FOREIGN KEY(mensagemid) REFERENCES tbmensagem(id) 
);

CREATE TABLE tbvoo(
   numvoo text,
   datpartida text,
   horpartida text,
   datchegada text,
   horchegada text,
   aerorigem text,
   aerdestino text,
   numpax integer,
   numcrew integer
);

