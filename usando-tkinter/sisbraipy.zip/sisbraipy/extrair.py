import os
import sys


if len(sys.argv) <= 2:
   print 'Mod de usar : python extrair.py arquivo coluna'
else: 
   arquivo = sys.argv[1]
   coluna = int(sys.argv[2])
   f=os.popen('wc -l '+arquivo)
   v=f.read().split(' ')
   c = 0
   arq = open(arquivo,'r')
   for linha in arq.readlines():
       c = c + 1
       if c > 2 and c < int(v[0])-1:
          vet = linha.split('|')
          try:
             print vet[coluna-1]
          except:
             print 'erro encontrado na linha : ',c
       
