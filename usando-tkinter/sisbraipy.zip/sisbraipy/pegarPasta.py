#!/usr/bin/python

from Tkinter import *
import os.path
from os import walk

class GetFolder:
   def __init__(self, raiz):
       self.root = raiz
       self.root.title('Escolher a pasta...')
       self.fr1 = Frame(self.root)
       self.fr1.pack()
       self.fr2 = Frame(self.root)
       self.fr2.pack()
       self.fr3 = Frame(self.root)
       self.fr3.pack()
       self.pathatual='/home/81784244368/sistemas/DPFAPI'
 
       self.e1 = Entry(self.fr1, width=40)
       self.e1.pack(side=LEFT)
       if os.path.exists(self.pathatual):
          self.e1.insert(0, self.pathatual)

       self.b1 = Button(self.fr1, text='Ir', command=self.irpara_click)
       self.b1.pack(side=LEFT)

       self.lb1 = Listbox(self.fr2, width=100)
       self.b2 = Button(self.fr3, text='Abrir', command=self.abrir_click)
       self.b3 = Button(self.fr3, text='Selecionar', command=self.selecionar_click)
       self.lb1.pack()
       self.b2.pack(side=LEFT)
       self.b3.pack(side=LEFT)

   def listar(self):
       caminhos=[]
       for (_,dirnames,_) in walk(self.pathatual):
           caminhos.extend(dirnames)
           break
       self.carregarLista(caminhos)
       
   def carregarLista(self, nos):
       if self.lb1.size()>0:
          self.lb1.delete(0, self.lb1.size())
       for item in nos:
          self.lb1.insert(self.lb1.size(), self.pathatual + "/" + item) 
           
   def irpara_click(self):
       if os.path.exists(self.e1.get()):
          self.pathatual=self.e1.get()
          self.listar()

   def abrir_click(self):
       item = self.lb1.curselection()
       valor = self.lb1.get(item[0])
       self.pathatual = valor
       # print "pegarPasta --->", self.pathatual
       self.e1.delete(0, len(self.e1.get()))
       self.e1.insert(0, valor)
       if os.path.isdir(valor):
          self.listar()

   def selecionar_click(self):
       self.root.quit()

# instancia=Tk()
# GetFolder(instancia)
# instancia.mainloop()
