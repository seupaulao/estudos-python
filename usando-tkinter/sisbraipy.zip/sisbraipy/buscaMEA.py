#!/usr/bin/python

import detalharApi
import sys
def imprimirSaida(edbv,parser):
     for pas in parser.passageiros:
         if len(pas.quantidadebagagem) > 0:
            if int(pas.quantidadebagagem) >= 20:
               print  "CT",edbv, parser.mensagem["identificacao"]
               print "Partida:",parser.mensagem["dataDecolagem"], parser.mensagem["horaDecolagem"] 
               print "Origem:", parser.mensagem["ultimoAeroportoDecolagem"], "Destino:",parser.mensagem["primeiroAeroportoAterrissagem"] 
               print pas.nome, pas.datanascimento, "Bagagem: ",pas.quantidadebagagem, "Peso:", pas.pesobagagem, "Unidade:", pas.unidadebagagem, "Etiqueta:", pas.etiquetabagagem
               print ' '
         if len(pas.pesobagagem) > 0:
            print  "WT",edbv, parser.mensagem["identificacao"]
            print "Partida:",parser.mensagem["dataDecolagem"], parser.mensagem["horaDecolagem"]
            print "Origem:", parser.mensagem["ultimoAeroportoDecolagem"], "Destino:",parser.mensagem["primeiroAeroportoAterrissagem"] 
            print pas.nome, pas.datanascimento, "Bagagem: ",pas.quantidadebagagem, "Peso:", pas.pesobagagem, "Unidade:", pas.unidadebagagem, "Etiqueta:", pas.etiquetabagagem
            print ' '
           
# MEACT/WT edbv voo datapartida horapartida origem destino nome nascimento qtebagagem pesobagagem unidadepeso etiquetas
def imprimirCsv(edbv,parser):
     for pas in parser.passageiros:
         if len(pas.quantidadebagagem) > 0:
            #if int(pas.quantidadebagagem) >= 20:
            print  "CT|",edbv,"|",parser.mensagem["identificacao"],"|",parser.mensagem["dataDecolagem"],"|", parser.mensagem["horaDecolagem"],"|", parser.mensagem["dataAterrissagem"], "|", parser.mensagem["horaAterrissagem"], "|", parser.mensagem["ultimoAeroportoDecolagem"], "|", parser.mensagem["primeiroAeroportoAterrissagem"], "|", pas.nome, "|", pas.datanascimento, "|", pas.quantidadebagagem, "|", pas.pesobagagem, "|", pas.unidadebagagem, "|", pas.etiquetabagagem
         if len(pas.pesobagagem) > 0:
            print  "WT|",edbv,"|",parser.mensagem["identificacao"],"|",parser.mensagem["dataDecolagem"],"|", parser.mensagem["horaDecolagem"],"|", parser.mensagem["dataAterrissagem"], "|", parser.mensagem["horaAterrissagem"], "|", parser.mensagem["ultimoAeroportoDecolagem"], "|", parser.mensagem["primeiroAeroportoAterrissagem"], "|", pas.nome, "|", pas.datanascimento, "|", pas.quantidadebagagem, "|", pas.pesobagagem, "|", pas.unidadebagagem, "|", pas.etiquetabagagem

def imprimirSomenteWT(edbv,parser):
     for pas in parser.passageiros:
         if len(pas.pesobagagem) > 0:
            print  "WT|",edbv,"|",parser.mensagem["identificacao"],"|",parser.mensagem["dataDecolagem"],"|", parser.mensagem["horaDecolagem"],"|", parser.mensagem["dataAterrissagem"], "|", parser.mensagem["horaAterrissagem"], "|", parser.mensagem["ultimoAeroportoDecolagem"], "|", parser.mensagem["primeiroAeroportoAterrissagem"], "|", pas.nome, "|", pas.datanascimento, "|", pas.quantidadebagagem, "|", pas.pesobagagem, "|", pas.unidadebagagem, "|", pas.etiquetabagagem
 
    
if len(sys.argv)>1:
   arquivo = sys.argv[1]
   if len(arquivo)>0:
      try:
         f = open(arquivo,'r')
         for frase in f.readlines():
             vetor = frase.split('|')
             if len(vetor) > 2:
                parser = detalharApi.ParserAPI('')
                parser.setCadeia(vetor[2])
                parser.tratarcadeia()
                parser.atualizarcaracteres()
                parser.iniciarParser()
                if len(sys.argv)==4:
                   imprimirSomenteWT(vetor[1],parser)
                elif len(sys.argv)==3:
                   imprimirCsv(vetor[1],parser)
                elif len(sys.argv)==2:
                   imprimirSaida(vetor[1],parser)         
                elif len(sys.argv)>4:
                   print 'ENTRADA INVALIDA'
         f.close()
      except:
         print 'ARQUIVO INVALIDO OU PATH INEXISTENTE' 
else:
   print 'MODO DE USAR: ./buscaMEA.py PATH OPCAO1 OPCAO2'
   print ' Se usar ./buscaMEA.py PATH - saida sera para esteticamente facil de ler'
   print ' Se usar ./buscaMEA.py PATH OPCAO1 saida sera um CSV cujo delimitador eh "|"'
   print ' Se usar ./buscaMEA.py PATH OPCAO1 OPCAO2 - saida sera somente para MEA WT em formato CSV com delimitador "|"'
   print ' Onde OPCAO1 e OPCAO2 pode ser qualquer numero ou letra como parametro'
