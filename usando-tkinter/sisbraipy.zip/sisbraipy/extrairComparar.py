import os
import sys


if len(sys.argv) <= 2:
   print 'Mod de usar : python extrairComparar.py arquivo1 coluna1 arquivo2 coluna2'
else: 
   arquivo1 = sys.argv[1]
   coluna1 = int(sys.argv[2])
   arquivo2 = sys.argv[3]
   coluna2 = int(sys.argv[4])
   
   #extrai as colunas dos arquivos
   vetor1=[]
   vetor2=[]
   arq = open(arquivo1,'r')
   for linha in arq.readlines():
       vet = linha.split('|')
       vetor1.append(vet[coluna1-1])
   arq.close()    

   arq = open(arquivo2,'r')
   for linha in arq.readlines():
       vet = linha.split('|')
       vetor2.append(vet[coluna2-1])
   arq.close()    
  
   print len(vetor1)
   print len(vetor2)
   
   #realiza a comparacao
   print '\n\nItens que estao no arquivo1 coluna1 mas nao estao em arquivo2 coluna2'
   c = 0
   for item in vetor1:
       if not item in vetor2:
          c += 1
          print item

   print 'Total Arquivos encontrados:',c

   print '\n\nItens que estao no arquivo2 coluna2 mas nao estao em arquivo1 coluna1'
   c = 0
   for item in vetor2:
       if not item in vetor1:
          c += 1
          print item

   print 'Total Arquivos encontrados:',c
