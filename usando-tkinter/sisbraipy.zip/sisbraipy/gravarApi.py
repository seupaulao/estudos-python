#/usr/bin/python

import os
import sys
import time
from datetime import date
import sqlite3

class Banco:
    def __init__(self, msg, paxandcrew):
        self.mensagem = msg
        self.passageiros = paxandcrew
        self.chave = ""
        self.codigoedbv = "06826"
        self.conexao = None 
    
    def abrirConexao(self):
        self.conexao = sqlite3.connect("apibase.db")

    def fecharConexao(self):
        self.conexao.close()

    def getSequencia(self, parametro):
        cursor = self.conexao.cursor()
        # pega o valor a ser usado
        cursor.execute("select valor from tbsequencia where id = ?", (parametro,))
        row = cursor.fetchone()
        maximo = -1 
        if row is None:
           print "Erro no banco. nao trouxe resultado"
        else:
           maximo = row[0]

        # incrementa o sequencial
        novo = maximo + 1
        cursor.execute("update tbsequencia set valor=? where id=?",(novo,parametro))
        self.conexao.commit() 

        cursor.close() 
        return maximo
 
    def getMesAnoAtual(self):
        dt = date.today()
        return dt.strftime("%m%Y") 

    def calcularChave(self, sequencial, dataPartida):
        return self.codigoedbv + "_" + dataPartida + "_" + str(sequencial) + self.getMesAnoAtual()

    def hoje(self):
        dt = date.today()
        return dt.strftime("%Y-%m-%d") 

    def getd(self, dic, par):
        try:
           return dic[par]
        except:
           return "" 

    def toInt(self, valor):
        if len(valor)>0:
           return int(valor)
        else:
           return 0

    def persistirMensagem(self):
        datadecolagem = ""
        try:
           datadecolagem = self.mensagem["dataDecolagem"]
        except:
           datadecolagem = ""
        if len(datadecolagem)>0:
           self.chave = self.calcularChave(self.getSequencia(1), self.mensagem["dataDecolagem"])
           print self.chave
           # TODO criar o insert da mensagem
           inserir='''
                 insert into tbmensagem (id, dtproc , data , 
                 hora , remetente , 
                 controleintercambio, nomecompanhiaaerea , 
                 grupofuncional , sigla ,    
                 numerounh ,   ispax ,    responsavel ,    
                 telefoneresponsavel ,     faxresponsavel ,   
                 emailresponsavel,   chegadasaida ,    identificacaovoo ,    primeiroaeroportoaterrissagem ,    
                 proximoaeroportodestino ,    ultimoaeroportodecolagem ,    
                 aeroportodestinacaofinal ,    datadecolagem ,    
                 dataaterrissagem ,    horadecolagem ,    
                 horaaterrissagem ,    quantidadepassageiros, 
                 quantidadetripulantes ) 
                 values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,
                 ?,?,?,?)'''         
           cur = self.conexao.cursor()  
           try:
             cur.execute(inserir, (self.chave, self.hoje(), self.mensagem["data"], self.mensagem["hora"], 
self.mensagem["remetente"],self.mensagem["controleintercambio"],self.mensagem["nomecompanhiaaerea"],
self.mensagem["grup funcional"],self.mensagem["sigla"],self.mensagem["numerounh"],self.mensagem["ispax"],
self.mensagem["responsavel"],self.getd(self.mensagem,"telefoneresponsavel"),self.getd(self.mensagem,"faxresponsavel"),
self.getd(self.mensagem,"emailresponsavel"),self.mensagem["chegadasaida"],self.mensagem["identificacao"],
self.mensagem["primeiroAeroportoAterrissagem"],self.getd(self.mensagem,"proximoAeroportoDestino"),
self.mensagem["ultimoAeroportoDecolagem"],self.getd(self.mensagem,"aeroportoDestinacaoFinal"),
self.mensagem["dataDecolagem"],self.mensagem["dataAterrissagem"],self.mensagem["horaDecolagem"],
self.mensagem["horaAterrissagem"],self.toInt(self.getd(self.mensagem,"quantidadePassageiros")),
self.toInt(self.getd(self.mensagem,"quantidadeTripulantes"))))
             self.conexao.commit() 
           except:
             self.conexao.rollback()
           cur.close()      

    def persistirPassageiros(self):
        inserir = ''' 
                insert into tbpassageiro(
		mensagemid , quantidadebagagem, pesobagagem, 
                unidadebagagem , etiquetabagagem , 
                nome ,  endereco,  cidade,  uf,  cep,   pais,   
                istransito,   ispax,  
                aeroportoprocedimentomigracao,   
                paisresidencia ,  aeroportoinicioviagem ,  
                aeroportofinalviagem ,   paisemissordocumento ,
		datanascimento ,  dataexpiracaodocumento ,  sexo ,  
                nacionalidade ,  numeromensagempnr ,  assento ,  
                referenciaunica ,
		tipodocumento ,  numerodocumento ,   codigogei ,   
                indicadorgei ) values (?,?,?,?,?,?,?,?,?,?,?,?,
                ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) '''
        cur=self.conexao.cursor()
        for pax in self.passageiros:
            cur.execute(inserir,(self.chave, pax.quantidadebagagem, pax.pesobagagem, pax.unidadebagagem, pax.etiquetabagagem,
                                 pax.nome, pax.endereco, pax.cidade, pax.uf, pax.cep, pax.pais, pax.istransito, pax.ispax,
                                 pax.aeroportoprocedimentomigracao, pax.paisresidencia, pax.aeroportoinicioviagem, pax.aeroportofinalviagem, pax.paisemissordocumento,
                                 pax.datanascimento, pax.dataexpiracaodocumento, pax.sexo, pax.nacionalidade, pax.numeromensagempnr, pax.assento, pax.referenciaunica,
                                 pax.tipodocumento, pax.numerodocumento, pax.codigogei, pax.indicadorgei))
        try:
            self.conexao.commit()  
        except:
            self.conexao.rollback()
            print "Erro ao tentar inserir algum passageiro"
        cur.close()
    
    def persistirVoo(self):
        
        chave = ""
        datadecolagem = ""

        try:
          chave=self.mensagem['identificacao']
        except:
          chave = ""
 
        try:
          datadecolagem = self.mensagem['dataDecolagem']
        except:
          datadecolagem = ""

        if len(chave)>0 and len(datadecolagem)>0:

           tuplabusca = (self.mensagem['identificacao'],self.mensagem['dataDecolagem'], self.mensagem['horaDecolagem'],
self.mensagem['ultimoAeroportoDecolagem'],self.mensagem['primeiroAeroportoAterrissagem'])

           numpax = 0
           numcrew = 0

           inserir = '''
           INSERT INTO tbvoo (numvoo, datpartida, horpartida, datchegada, 
           horchegada, aerorigem, aerdestino, numpax, numcrew ) VALUES (
           ?,?,?,?,?,?,?,?,?) '''

           consultar = '''
           SELECT NUMPAX,NUMCREW FROM TBVOO WHERE 
           NUMVOO=? AND DATPARTIDA=? AND HORPARTIDA=? AND
           AERORIGEM=? AND AERDESTINO=? '''        

           alterar = '''
           UPDATE tbvoo SET NUMPAX=?, NUMCREW=? WHERE
           NUMVOO=? AND DATPARTIDA=? AND HORPARTIDA=? AND
           AERORIGEM=? AND AERDESTINO=? '''        

           cur=self.conexao.cursor()
           rs = cur.execute(consultar, tuplabusca)
           resultado = rs.fetchone()
           if not resultado:
              if self.mensagem['ispax']:
                 numpax = len(self.passageiros)
              else:
                 numcrew = len(self.passageiros)

              tuplainsert = (self.mensagem['identificacao'], 
self.mensagem['dataDecolagem'], self.mensagem['horaDecolagem'],
self.mensagem['dataAterrissagem'],self.mensagem['horaAterrissagem'],
self.mensagem['ultimoAeroportoDecolagem'],
self.mensagem['primeiroAeroportoAterrissagem'],numpax,numcrew)
              try:
                 cur.execute(inserir, tuplainsert)
                 self.conexao.commit()
              except:
                 self.conexao.rollback()        
           else:
              numpax = resultado[0]
              numcrew = resultado[1]   
              if self.mensagem['ispax']:
                 numpax += len(self.passageiros)  
              else:
                 numcrew += len(self.passageiros)
           
              tuplaalterar = (numpax,numcrew,self.mensagem['identificacao'], 
self.mensagem['dataDecolagem'], self.mensagem['horaDecolagem'],
self.mensagem['ultimoAeroportoDecolagem'],
self.mensagem['primeiroAeroportoAterrissagem'])
              try:
                 cur.execute(alterar, tuplaalterar)
                 self.conexao.commit()
              except:
                 self.conexao.rollback()

           cur.close()

    def persistir(self):
        self.abrirConexao()
        self.persistirMensagem()
        self.persistirPassageiros()
        self.persistirVoo()
        self.fecharConexao() 

